/**
 * 
 */
/**
 * 
 */
module MY2DGamee {
	requires java.desktop;
}